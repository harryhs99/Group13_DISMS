const loginForm = document.getElementById('loginForm');
const username = document.getElementById('username');
const email = document.getElementById('email');
const resetpwd = document.getElementById('resetpwd');

loginForm.addEventListener('submit',function(e){
    e.preventDefault();
    console.log('start');
    
    fetch('http://localhost:8080',{ // staff resetpassword
        method:'POST',
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({
            username: username,
            email: email,
            resetpwd:resetpwd
        })
    })
    .then(Response=>{
        if(!Response.ok){
            throw new Error("Wrong request" + Response.statusText);
        }else{
            
            alert("Reset successfully!!");
            window.location.href = "DysonLogin.html";
            return Response.json();
        }
    })
    .catch(error =>{
        console.error("Error is:" ,error);
    });
});

