
//-------------------------------------sidepanel--------------------------------

const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});

// ------------------------main part-----------------------------

// submit form to backend to get student's info
const searchDetail = document.getElementById('searchDetail');
const submitBtn = document.getElementById('submitBtn');

searchDetail.addEventListener('submit',function(e){
    e.preventDefault();

    const searchID = document.getElementById('searchID').value;

    // get id
    fetch('http://localhost:8080',{ // use student id to get data
        method:'GET',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ SearchID:searchID }) // As a keyword
    })
    .then(response=>{
       if(!response.ok){
        alert('Cannot get the data');
        throw new Error('Fail');
       }
       return response.json();

    })
    .then(data=>{// if stuid exist then display the data
        if(data.exists){
            StuDetaildata(stuAllDetail);
            StuPersonalInfo(stuAllDetail);
        }else{
            alert("the student doesn't exist");
        }
    })
    .catch(error=>{
        console.log('cannot get any info:', error)
    });
});



// below data is for testing, ideally get data in array from backend
const stuAllDetail =[
    {StuID:'0001',ModuleID:'Dyson01',Coursework:'report 1',Coursework_Grades:70,Exams:'Digital Exam',Exams_Grade:65,StuName:'Ben',StuEmail:'123456@gmail.com',Academi_History:'No related Background'}
]

const Detailtbody = document.getElementById('Detailtbody');
const Infotbody = document.getElementById('Infotbody');
const Detailtable = document.getElementById('Detailtable');
const Infotable = document.getElementById('Infotable');
const row = document.createElement('tr');

// ----delete later-----
StuDetaildata(stuAllDetail);
StuPersonalInfo(stuAllDetail);

function StuDetaildata(stuAllDetail){
    for(let i =0; i<stuAllDetail.length;i++){
        const row = document.createElement('tr');
        row.innerHTML = 
        `<td>${stuAllDetail[i].StuID}</td>
         <td>${stuAllDetail[i].ModuleID}</td>
         <td>${stuAllDetail[i].Coursework}</td>
         <td>${stuAllDetail[i].Coursework_Grades}</td>
         <td>${stuAllDetail[i].Exams}</td>
         <td>${stuAllDetail[i].Exams_Grade}</td>`;

         Detailtbody.appendChild(row);
    }

}

function StuPersonalInfo(){
    for(let i =0; i<stuAllDetail.length;i++){
        const row = document.createElement('tr');
        row.innerHTML = 
        `<td>${stuAllDetail[i].StuID}</td>
         <td>${stuAllDetail[i].StuName}</td>
         <td>${stuAllDetail[i].StuEmail}</td>
         <td>${stuAllDetail[i].Academi_History}</td>`

         Infotbody.appendChild(row);

    }
}

