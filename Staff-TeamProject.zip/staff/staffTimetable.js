//-------------------------------------sidepanel--------------------------------

const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});


// ----------- timetable part---------

const tds = document.querySelectorAll('.content td');
const popBox = document.getElementById('popBox');
const selectRoom = document.getElementById('selectRoom');
const selectModule = document.getElementById('selectModule');
const selectLecturer = document.getElementById('selectLecturer');

const subBtn = document.getElementById('subBtn');
const deleteBtn = document.getElementById('deleteBtn');
const cancelBtn = document.getElementById('cancelBtn');
// submit timetable button
const submit = document.getElementById('submit');
const content = document.querySelector('.content');






let check;
function handle(e){
    check = e.target
    if (check.classList.contains('td')) {
        
        popBox.style.display = 'block';
        popBox.style.left = e.clientX +'px';
        popBox.style.top = e.clientY +'px';

                     
        subBtn.addEventListener('click', subBtnClick);
        deleteBtn.addEventListener('click',deleteBtnClick);       
        cancelBtn.addEventListener('click',cancelBtnCLick);

    }
}
content.addEventListener('click', handle);

function subBtnClick(){
    //  display data on the table
    check.textContent =                 
        `Module: ${selectModule.value}
        Room: ${selectRoom.value} 
        Lecturer: ${selectLecturer.value} `;    
    // hidden popBox
    popBox.style.display = 'none';
    subBtn.removeEventListener('click', subBtnClick);
}
function deleteBtnClick(){
    check.textContent = ' ';
    popBox.style.display = 'none';
    deleteBtn.removeEventListener('click',deleteBtnClick);
    subBtn.removeEventListener('click', subBtnClick);
}
function cancelBtnCLick(){
    popBox.style.display = 'none';
    cancelBtn.removeEventListener('click',cancelBtnCLick);
    deleteBtn.removeEventListener('click',deleteBtnClick);
    subBtn.removeEventListener('click', subBtnClick);
}


// ------ sumbit to database ------

submit.addEventListener('click',function(e){
    e.preventDefault();
    tds.forEach(td=>{
        td.addEventListener('click',function(){
            const slotID = this.getAttribute('id');
            const inputData = this.textContent;

            const getID = document.getElementById('ID').value;
    const selectWeek = document.getElementById('selectWeek').value;
    const selectMonth = document.getElementById('selectMonth').value;

    fetch('http://localhost:8080',{  // send timetable from backend
        method:'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
            ID:getID,
            Week: selectWeek,
            Month:selectMonth,
            slotID:slotID,   
            timmTableData:inputData       
 }) 
    })
    .then(response=>{
       if(!response.ok){
        alert('Failed');
        throw new Error('Fail');
       }
       alert('Send successfully');
       return response.json();

    })
    .catch(error=>{
        console.log('cannot get any info:', error)
    })
    
})
        })
    })
     

    




