//--------------------------sidepanel---------------------
const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});

// ----- Connect to backend-------
const submitBtn = document.getElementById('submitBtn');
submitBtn.addEventListener('click',function(e){
    e.preventDefault();

    const marks = document.getElementById('marksBox').value;
    const stuID = document.getElementById('IDBox').value;
    const feedback = document.getElementById('feedbackBox').value;

    fetch('http://localhost:8080',{ // submit students' feedback,marks,id
        method:"POST", 
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ 
            Marks: marks,
            StuID:stuID,
            Feedback:feedback
        }) 
        .then(Response=>{
            if(!Response.ok){
                alert("Failed");
                throw new Error("Wrong request" + Response.statusText);
                
            }else{
                alert("Send successfully!!")
                return Response.json();
            }
        })
        .catch(error =>{
            console.error("Error is:" ,error);
        })
    })
})
