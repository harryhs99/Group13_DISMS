//-------------------------------------sidepanel--------------------------------

const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});


// ------------------enddate cannot earlier than startdate----------
const form = document.getElementById('form');
const cks = document.querySelectorAll('.ck');
const startDate = document.getElementById('startDate');
const endDate = document.getElementById('endDate');

   // end date cannot earlier than start date
   startDate.addEventListener('input',function(){
    const start = startDate.value;
    if(start<endDate.value && endDate.value!=null){
      console.log("correct");
    }
 
   })
   endDate.addEventListener('input',function(){
    const end = endDate.value;
    if( end<startDate.value ){
      alert('endDate cannot earlier than startDate')
    }
   })

// submit form to backend
form.addEventListener('submit',function (e){
   e.preventDefault();
   console.log("catch the Event");

   let checked = false;
   for(let i =0;i<cks.length;i++){
    if(cks[i].checked){
        checked = true;
        break;
    }
   }



// submit form to back end
const formData = new FormData(form);
fetch ("url(update) " ,{ //------- server's url--------
   method:"POST",
   headers:{
    "Content-Type":"application/x-www-form-urlencoded"
   },
   body:JSON.stringify(formData)
})
.then(response=>{
    if(!response.ok){
        throw new Error("Wrong request" + response.statusText);
    }else{
        return response.json(); // Parse the data returned by the server
    }
})

.then(data=>{
    console.log("data return from server:",data); // data just a variable, it can be any names
})
.catch(error =>{
    console.error("Error is:" ,error);
})

});
