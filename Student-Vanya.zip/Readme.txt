# If your laptop system language is Chinese, then some elements may display in Chinese.


----Coursework-----
+ This is for students to check their exams' marks,submit their coursework and extend their courseworks
+ I am not sure how to write js in this page.


----Extension---- 
+ This is for students extend their courseworks.
+ I write some js about send data to backend, but no idea if it can work.

-----Submit--------
+ submit file （coursework） to backend
+ I am not sure if it could success, we can discuss abou it.


----personalSituation-----
+ This is for student to make an appointment with tutor and submit their applicaiton for attendence
+ There is a method named sendData() to get connection to backend, the url is the server url.
+ I am not sure if make an appointment with tutor, how the tutor know this message? via email?

------StudentTimetable------
+ check details about each module.
+ get data from backend: I write some comments on JS, you guys can have a look.

------WSE----------

+ WSE = withdraw + suspend + enroll
+ If you have a good name can replace this name
+ I don't know what is the [suspend] function for,so I don't know how to write  js on this button.
+ About [enroll] function you can add more elements on this page,after adding, you may need to modify js (or maybe not).
+ The data in table is written in JS, and render on HTML.
+ The connection to backend I'm not sure it can work.
+ I also write some comments on JS, you guys can have a look.


Vanya