//-------------------------------------sidepanel--------------------------------

const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});


// --------connect to backend-----//
// click  button and upload
// reference:https://blog.csdn.net/weixin_42332166/article/details/133495433


const button = document.getElementById('submitButton').addEventListener('click',function(){
    uploadFile();
});
function uploadFile(){
    const fileInput = document.getElementById('file_input');
    const status = document.getElementById('uploadStatus');
    const file = fileInput.files[0];
    if (file){
    // create FormData object
    const formData = new FormData();
    formData.append('file',file)
    // create a XMLHttpRequest to send HTTP request
    const xhr = new XMLHttpRequest();
    //initialize
    xhr.open('POST','url',true) // url == the endpoint of back-end
    xhr.send(formData)
    //check the status
    xhr.onreadystatechange=function(){
        if(xhr.readyState===4 &&xhr.status===200){
           status.value = 'upload successfully.';
        }else{
           status.value = 'upload unsuccessfully.'
        }
    }
    }else{
        alert('please upload a file.');
    }
};

// click 'Coursename' and return a coursename on front-end
 const list = document.querySelectorAll('.list');
 const coursename = document.getElementById('courseName');
 list.forEach(item =>{
 item.addEventListener('click',function(event){
    if(event.target.tagName === 'A'){
        const textLink = event.target.textContent;
        coursename.textContent ='CourseName:'+ textLink;
    }
});
 });

// ------- Click coursename and then show up relevant info------
document.addEventListener('DOMContentLoaded',()=>{
    // get all the <a>, and display each details to html
    const links = document.querySelectorAll('#mainPart a');
    links.forEach(function(link){

        link.addEventListener('click',function(e){
            e.preventDefault();
        

            //Fetch API
            fetch('url', { // url == server's link
                method: 'GET',
                headers: {
                'Content-Type': 'application/json'
                }
            })
            .then(res => {
                if (res.ok) {
                return res.json();
                }
                throw new Error('Network response was not ok.');
            })
            .then(data => {
                document.getElementById('dueTime').textContent = 'Due Date: ' + data.deadline;
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
            
        
        
        });
    });
});