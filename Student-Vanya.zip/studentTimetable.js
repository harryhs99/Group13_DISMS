// Just some ideas, I have no ideas how to get timetable from DB



//-------------------------------------sidepanel--------------------------------
const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});

//-----------------------------------------------------------------------------------

// Get data from DB,below data just for testing
// Ideally, get data from backend in array, then I may use Moduledata() method to render data to html
const timetableData = [
    {moduleCode:'Dyson01',Duration:'10 weeks',Venue:'USB',Time:'10:00-11:00',Lecturer:'Dan'},
    {moduleCode:'Dyson02',Duration:'10 weeks',Venue:'USB',Time:'11:00-12:00',Lecturer:'Dan'},
    {moduleCode:'Dyson03',Duration:'10 weeks',Venue:'USB',Time:'11:00-12:00',Lecturer:'Dan'}
];
// Get panel from html
const table = document.getElementById('table');
// insert data into table
const tbody = document.getElementById('tbody_');
const row = document.createElement('tr');
Moduledata();


// ------------------function() below--------------------------
// loop to add data to the table
function Moduledata(){
    for(let i =0;i<timetableData.length;i++){
        const row = document.createElement('tr');

        row.innerHTML = 
            `<td>${timetableData[i].moduleCode}</td>
            <td>${timetableData[i].Duration}</td>
            <td>${timetableData[i].Venue}</td>
            <td>${timetableData[i].Time}</td>
            <td>${timetableData[i].Lecturer}</td>`;

            // add two buttons to the table

        tbody.appendChild(row);
    }
    return tbody;
}




















// const timetableData = {}
// // Get panel from html
// const table = document.getElementById('table');
// // insert data into table
// const tbody = document.getElementById('tbody_');
// timetableData.forEach(data =>{
//     const row = document.createElement('tr');
//     // create array to store each td's attribute
//     const cells = [data.moduleCode,data.Duration,data.Venue,data.Time,data.Lecturer];
//     cells.forEach(cell=>{
//         const td = document.createElement('td');
//         // add each td into rows
//         row.appendChild(td);
//     });
//     // add each row into tbody
//     tbody.appendChild(row);
// }) ;
// table.appendChild(tbody);

