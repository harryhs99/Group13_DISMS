// --------- sidepane----------
const navbar_toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById('sidebar');
navbar_toggle.addEventListener('click',function(){
    sidebar.classList.toggle('show');
});


// ----------main----------

// Feedback page - set its window size

const links = document.querySelectorAll('.link');
links.forEach(function(e){
    e.addEventListener('click',function(event){
        event.preventDefault();
        const new_window = window.open('http://127.0.0.1:5500/Feedback.html','_blank','width=700,height=400,top=100,left=100');
    });

});


//--------------- haven't write any code about API--------------------

