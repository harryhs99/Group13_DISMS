// -------------------------------------TopNav----------------------------------


//-------------------------------------sidepanel--------------------------------

const toggle = document.getElementById('navbar_toggle');
const sidebar = document.getElementById("sidebar");
toggle.addEventListener("click", function() {
    sidebar.classList.toggle("show");
});

// -----------------------------------main-----------------------------------


//----- switch pages------
const tab_nav = document.querySelector('.tab-nav')
const pane = document.querySelectorAll('.pane')

tab_nav.addEventListener('click', function (e) {
  if (e.target.tagName === 'A') {
    // remove "active" 
    tab_nav.querySelector('.active').classList.remove('active')
    // add "active" to that element that click
    e.target.classList.add('active')

    // remove all the displayed element
    for (let i = 0; i < pane.length; i++) {
    // remove all the displayed element
      pane[i].style.display = 'none'
    }
    // and then add the one which really click
    pane[e.target.dataset.id].style.display = 'block'
  }
})

// add event to "button"
const form = document.getElementById('enrol');
const enrolBtn = document.getElementById('enrolBtn');
enrolBtn.addEventListener('submit',function(){
    const formdata = new FormData(form);
    sendToBackEnd(formdata);
})

// Just some ideas, I have no ideas how to get timetable from DB

// Get data from DB,below data just for testing，ideally get data from backend in array, then can render it 
const timetableData = [
    {moduleCode:'Dyson01',Duration:'10 weeks',Venue:'USB',Time:'10:00-11:00',Lecturer:'Dan'},
    {moduleCode:'Dyson02',Duration:'10 weeks',Venue:'USB',Time:'11:00-12:00',Lecturer:'Dan'},
    {moduleCode:'Dyson03',Duration:'10 weeks',Venue:'USB',Time:'11:00-12:00',Lecturer:'Dan'}
];

// Get panel from html
const table = document.getElementById('table');
// insert data into table
const tbody = document.getElementById('tbody_');
const row = document.createElement('tr');
const sendData = data();
sendToBackEnd(sendData);

// ------------------function() below,haven't write anything about suspend--------------------------

// loop to add data to the table,dynamically add buttons and rows
function data(){
    for(let i =0;i<timetableData.length;i++){
        const row = document.createElement('tr');
        const action = document.createElement('td');
        const withdrawBtn = document.createElement('button');
        withdrawBtn.textContent = 'withdraw';
        const suspendBtn = document.createElement('button');
        suspendBtn.textContent = 'suspend';
        row.innerHTML = 
            `<td>${timetableData[i].moduleCode}</td>
            <td>${timetableData[i].Duration}</td>
            <td>${timetableData[i].Venue}</td>
            <td>${timetableData[i].Time}</td>
            <td>${timetableData[i].Lecturer}</td>`;

            // add two buttons to the table,
        action.appendChild(withdrawBtn);
        row.appendChild(action);
        action.appendChild(suspendBtn);
        row.appendChild(action);
        tbody.appendChild(row);

        // delete one record
        withdrawBtn.addEventListener('click',()=>{
            deleteRow(withdrawBtn);
            alert('delete one row');
        })

    }
    return tbody;
}


function deleteRow(button){
    const row = button.closest('tr');
    if(row !=null){
        row.remove();
    }
}
//  ---- send data to backend------
function sendToBackEnd(data){
       
        fetch('url',{
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data) 
        })
            .then(response => {
                if (!response.ok) {
                    throw new Error('Network response was not ok');
                }
                return response.json(); 
            })
            .then(responseData => {
                console.log('Data saved successfully:', responseData);
            })
            .catch(error => {
                console.error('Error saving data to backend:', error);
            });
    

}


// timetableData.forEach(data =>{
//     const row = document.createElement('tr');
//     // create array to store each td's attribute
//     const cells = [data.moduleCode,data.Duration,data.Venue,data.Time,data.Lecturer];
//     cells.forEach(cell=>{
//         const td = document.createElement('td');
//         // add each td into rows
//         row.appendChild(td);
//     });
//     // add each row into tbody
//     tbody.appendChild(row);
// }) ;
// table.appendChild(tbody);

