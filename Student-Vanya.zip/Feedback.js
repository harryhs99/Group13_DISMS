// assume already got data from DB
const data = {};
// store the data
localStorage.setItem('text',JSON.stringify);
if(localStorage.getItem('text')){
    const text = JSON.parse(localStorage);
    const content = document.getElementById('conetent');
    content.value = text;
}


