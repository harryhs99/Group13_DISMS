// ---------------------------------- Side Panel Toggle -----------------------------------
const body = document.querySelector("body");
const toggle = body.querySelector(".toggle");
const sidebar = body.querySelector(".sidebar");
const examNav = body.querySelector(".examNav");

toggle.addEventListener("click", function() {
    sidebar.classList.toggle("close");
    examNav.classList.toggle("open")
});


// ---------------------------------- Subject Navigation -----------------------------------

document.addEventListener('DOMContentLoaded', function () {
    // document.getElementById('myTextarea').value = '';
});




// ---------------------------------- Exam Navigation -----------------------------------

document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll('.nav-link a'); // Select all navigation links
    const sections = document.querySelectorAll('section'); 

    // Function to close all sections
    function closeAllSections() {
        sections.forEach(section => {
            section.classList.add('close');
        });
    }
    
    // Open coursework result by default
    const courseworkSection = document.getElementById('coursework');
    courseworkSection.classList.remove('close');
    

    // Event listeners for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetSection = document.querySelector(this.getAttribute('href')); 
            closeAllSections(); // Close all sections
            targetSection.classList.remove('close'); // Open the targeted section
        });
    });
});


//-------------------------------------------- Coursework Result ---------------------------------------------

const links = document.querySelectorAll('.link');
links.forEach(function(e){
    e.addEventListener('click',function(event){
        event.preventDefault();
        const new_window = window.open('http://127.0.0.1:5500/Feedback.html','_blank','width=700,height=400,top=100,left=100');
    });

});

// Haven't write any js connect to backend


//-------------------------------------------- Past Year Paper ---------------------------------------------

// get file from db
const filecontent = document.getElementById("filecontent");
fetch('url', { // url == server's link
    method: 'GET',
    })
    .then(res => {
        if (res.ok) {
        return res.text();
        }
        throw new Error('Network response was not ok.');
    })
    .then(filecontent => {
        filecontent.textContent = filecontent;
    })
    .catch(error => {
        console.error('There was a problem with the fetch operation:', error);
        filecontent.textContent = 'Fail to catch the file';
    });


//-------------------------------------------- Submission ---------------------------------------------
// submit courseworkfile to the backend
const submitForm = document.getElementById('submitForm');
const uploadStatus = document.getElementById('uploadStatus');

submitForm.addEventListener('submit', function(e){
    e.preventDefault();

    const formData = new FormData();
    formData.append('uploadFile',uploadFile.file[0]);

    fetch('url', {
        method: 'POST',
        body: formData
      })
      .then(response => {
        if (!response.ok) {
          throw new Error('Upload unsuccessfully');
        }
        return response.text(); 
      })
      .then(data => {
        uploadStatus.textContent = 'Submit Successfully';
      })
      .catch(error => {
        console.error('There is an error:', error);
        uploadStatus.textContent = 'Submit Unsuccessfully, please try again';
      });
    });


// click 'Coursename' and return a coursename on front-end
 const list = document.querySelectorAll('.classList');
 const coursename = document.getElementById('courseName');
 list.forEach(item =>{
 item.addEventListener('click',function(event){
    if(event.target.tagName === 'A'){
        const textLink = event.target.textContent;
        coursename.textContent ='CourseName:'+ textLink;
    }else{
        console.log("fail");
    }
});
 });

// ------- Click coursename and then show up relevant info------
document.addEventListener('DOMContentLoaded',()=>{
    // get all the <a>, and display each details to html
    const links = document.querySelectorAll('#mainPart a');
    links.forEach(function(link){

        link.addEventListener('click',function(e){
            e.preventDefault();
        

            //Fetch API
            fetch('url', { // url == server's link
                method: 'GET',
                headers: {
                'Content-Type': 'application/json'
                }
            })
            .then(res => {
                if (res.ok) {
                return res.json();
                }
                throw new Error('Network response was not ok.');
            })
            .then(data => {
                document.getElementById('dueTime').textContent = 'Due Date: ' + data.deadline;
            })
            .catch(error => {
                console.error('There was a problem with the fetch operation:', error);
            });
            
        
        
        });
    });
});


//-------------------------------------------- Extension ---------------------------------------------


// ------------------enddate cannot earlier than startdate----------
const form = document.getElementById('extensionForm');
const cks = document.querySelectorAll('.ck');
const startDate = document.getElementById('startDate');
const endDate = document.getElementById('endDate');

   // end date cannot earlier than start date
   startDate.addEventListener('input',function(){
    const start = startDate.value;
    if(start<endDate.value && endDate.value!=null){
      console.log("correct");
    }
 
   })
   endDate.addEventListener('input',function(){
    const end = endDate.value;
    if( end<startDate.value ){
      alert('endDate cannot earlier than startDate');
      endDate.value =' ';
    }
   })

// submit form to backend
form.addEventListener('submit',function (e){
   e.preventDefault();
   console.log("catch the Event");

   let checked = false;
   for(let i =0;i<cks.length;i++){
    if(cks[i].checked){
        checked = true;
        break;
    }
   }



    // submit form to back end
    const formData = new FormData(form);
    fetch ("url(update) " ,{ //------- server's url--------
    method:"POST",
    headers:{
        "Content-Type":"application/x-www-form-urlencoded"
    },
    body:JSON.stringify(formData)
    })
    .then(response=>{
        if(!response.ok){
            throw new Error("Wrong request" + response.statusText);
        }else{
            return response.json(); // Parse the data returned by the server
        }
})

.then(data=>{
    console.log("data return from server:",data); // data just a variable, it can be any names
})
.catch(error =>{
    console.error("Error is:" ,error);
})

});
