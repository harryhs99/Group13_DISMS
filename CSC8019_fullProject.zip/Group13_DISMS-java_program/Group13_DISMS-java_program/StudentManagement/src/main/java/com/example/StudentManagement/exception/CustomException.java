package com.example.StudentManagement.exception;

public class CustomException {
}
