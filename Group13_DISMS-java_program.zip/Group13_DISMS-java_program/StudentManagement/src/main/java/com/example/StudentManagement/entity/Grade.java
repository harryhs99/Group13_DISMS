package com.example.StudentManagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * Entity class representing a student's grade in a module.
 *  * @author Jiaming LIU
 *  * @Date 6th May
 */
@Entity
@Table(name = "grade")
public class Grade {
    @Id
    @Column(name = "StudentID")
    private String studentID; // The ID of the student to which the grade belongs

    @Id
    @Column(name = "ModuleCode")
    private String moduleCode; // The code of the module for which the grade is given

    @Column(name = "Grade")
    private String grade; // The grade (e.g., A, B, C) received by the student

    // Getter methods
    public String getModuleCode() {
        return moduleCode;
    }

    public String getStudentID() {
        return studentID;
    }

    public String getGrade() {
        return grade;
    }

    // Setter methods
    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }
}
