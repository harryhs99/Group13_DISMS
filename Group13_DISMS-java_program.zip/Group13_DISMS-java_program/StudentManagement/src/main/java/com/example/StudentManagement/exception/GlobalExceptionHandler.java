package com.example.StudentManagement.exception;

public class GlobalExceptionHandler {
}
