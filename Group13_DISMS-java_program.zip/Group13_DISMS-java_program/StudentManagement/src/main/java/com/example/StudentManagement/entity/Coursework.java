package com.example.StudentManagement.entity;

import javax.persistence.*;
import java.time.LocalDateTime;
/**
 * Represents a coursework entity with details about assessments.
 *  * @author Jiaming LIU
 *  * @Date 6th May
 */
@Entity
@Table(name = "coursework")
public class Coursework {

    @Id
    @Column(name = "AssessmentID", nullable = false)
    private String assessmentID;// Unique identifier for the coursework

    @Column(name = "Title", nullable = false)
    private String title;// Title of the coursework

    @Column(name = "Deadline")
    private LocalDateTime deadline; // Deadline for submitting the coursework

    @Column(name = "ModuleCode", nullable = false)
    private String moduleCode;// Code of the module to which the coursework belongs

    @Column(name = "Grade")
    private Integer grade;// Grade received for the coursework

    @Column(name = "Feedback")
    private String feedback;// Instructor's feedback on the coursework

    @Column(name = "FilePath")
    private String filePath; // File path to the submitted coursework document

    @Column(name = "StudentID", nullable = false)
    private String studentID;// ID of the student who submitted the coursework

    // getters and setters

    public String getFeedback() {
        return feedback;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public String getTitle() {
        return title;
    }

    public Integer getGrade() {
        return grade;
    }

    public LocalDateTime getDeadline() {
        return deadline;
    }

    public String getAssessmentID() {
        return assessmentID;
    }

    public String getFilePath() {
        return filePath;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setFeedback(String feedback) {
        this.feedback = feedback;
    }

    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public void setAssessmentID(String assessmentID) {
        this.assessmentID = assessmentID;
    }

    public void setDeadline(LocalDateTime deadline) {
        this.deadline = deadline;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }
}
