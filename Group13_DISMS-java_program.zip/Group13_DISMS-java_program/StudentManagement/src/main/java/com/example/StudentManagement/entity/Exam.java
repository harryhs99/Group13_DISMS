package com.example.StudentManagement.entity;

import javax.persistence.*;
import java.time.LocalDateTime;

/**
 * Entity class representing an exam within a student management system.
 *  * @author Jiaming LIU
 *  * @Date 6th May
 */
@Entity
@Table(name = "exam")
public class Exam {

    @Id
    @Column(name = "AssessmentID", nullable = false)
    private String assessmentID; // Unique identifier for the exam

    @Column(name = "Title", nullable = false)
    private String title; // Title of the exam

    @Column(name = "Location")
    private String location; // Location where the exam is held

    @Column(name = "StartTime")
    private LocalDateTime startTime; // Start time of the exam

    @Column(name = "EndTime")
    private LocalDateTime endTime; // End time of the exam

    @Column(name = "ModuleCode", nullable = false)
    private String moduleCode; // Code of the module to which the exam belongs

    @Column(name = "grade")
    private Integer grade; // Grade received by the student for this exam

    @Column(name = "StudentID", nullable = false)
    private String studentID; // ID of the student who took the exam

    // Getter and setter methods

    public String getAssessmentID() {
        return assessmentID;
    }

    public void setAssessmentID(String assessmentID) {
        this.assessmentID = assessmentID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public String getModuleCode() {
        return moduleCode;
    }

    public void setModuleCode(String moduleCode) {
        this.moduleCode = moduleCode;
    }

    public Integer getGrade() {
        return grade;
    }

    public void setGrade(Integer grade) {
        this.grade = grade;
    }

    public String getStudentID() {
        return studentID;
    }

    public void setStudentID(String studentID) {
        this.studentID = studentID;
    }
}
