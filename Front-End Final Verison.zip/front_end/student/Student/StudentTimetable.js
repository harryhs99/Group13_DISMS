 /*
* @ param {Object}body, get element from HTML
* @ param {Object}toggle, get element from HTML
* @ param {Object}sidebar, get element from HTML
* @ param {Object}subNav, get element from HTML

* @ param {Object}tds, get element from HTML
* @ param {Object}show, get element from HTML
* @ param {function}getMonday,get day
* @ param {function}setDate, set date to system
* @ param {function}clearTable, clear the table



 @ author: Zhiqing Liang & YangCheng Liu
 Date: April 27,2024
 Copyright(c) 2024 Newcastle University,UK
*/ 

//-------------------------------------sidepanel--------------------------------

const body = document.querySelector("body");
const toggle = body.querySelector(".toggle");
const sidebar = body.querySelector(".sidebar");

toggle.addEventListener("click", function() {
    sidebar.classList.toggle("close");
    subNav.classList.toggle("open")
});


// ----------- timetable part---------

const tds = document.querySelectorAll('.content .td');
const show = document.getElementById('show');

//get current date, calculate the date of Monday this week
//set the date for the head of the table
var curSelectDate = new Date();
setDate(getMonday(curSelectDate));
//

function getMonday(d) {
  d = new Date(d);
  var day = d.getDay(),
      diff = d.getDate() - day + (day == 0 ? -6:1); // adjust when day is Sunday
  return new Date(d.setDate(diff));
}
//
function setDate(d){
d = new Date(d);
let month = d.getMonth() + 1;
let day = d.getDate();
//console.log(d.toDateString());
for (let i = 1; i <= 5; i++) {
    let dayCell = document.getElementById("day" + i);

    dayCell.innerText = `${month}.${day}`;
    //please notice month in javascript start from 0
    //therefore May is 4
    d.setDate(d.getDate()+1);
    day = d.getDate();
    month = d.getMonth() + 1;
    }
}
function clearTable(){
    tds.forEach(function(td) {
     td.innerText = "";
    });
    }


// ----- click btn to show timetable---

show.addEventListener("click",function(e){
    e.preventDefault();
    const selectDate = document.getElementById("selectDate").value;
    console.log(selectDate);
    clearTable();
    curSelectDate = new Date(selectDate);
    let mondayDate = getMonday(curSelectDate);
    //set the date for the head of the table
    setDate(mondayDate);
    //get timetable from back end
    const moduleCode = "CSC8019";
    let year = mondayDate.getYear();
    let month = mondayDate.getMonth()+1;
    let day = mondayDate.getDate();

    //  Get data from backend
    const endpoint = "http://localhost:8080/timetable/getTimetableTest";
    fetch( endpoint + `?moduleCode=${moduleCode}&year=${year}&month=${month}&day=${day}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
      }
    })
    .then(response => response.json())
    .then(data => {
        data.forEach(function(element){
        curSlot = document.getElementById(element.slotID);
        curSlot.innerText = element.content;
        })
    })
    .catch((error) => {
      console.error('Error:', error);
    });

})




