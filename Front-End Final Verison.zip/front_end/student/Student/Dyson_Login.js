 /*
 @ author: Zhiqing Liang & YangCheng Liu
 Date: April 20,2024
 Copyright(c) 2024 Newcastle University,UK
*/ 

//  Get element and add listener
const loginForm = document.getElementById('loginForm');
loginForm.addEventListener('submit',function(e){
    e.preventDefault();
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
    sessionStorage.setItem("username",username);
    fetch('http://localhost:8080/student/login',{ // student login
        method:'POST',
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({  // send userID and userPassword to backend
            userID: username,
            userPassword: password
        })
    })
    .then(Response=>{
        if(!Response.ok){
            alert("invalid password or username");
            throw new Error("Wrong request" + Response.statusText);

        }else{
        alert("ok")
            window.location.href = "Main.html";
            return Response.json();
        }
    })
    .catch(error =>{
        console.error("Error is:" ,error);
    });
});