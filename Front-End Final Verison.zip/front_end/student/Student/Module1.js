 /*
* @ param {Object}body, get element from HTML
* @ param {Object}toggle, get element from HTML
* @ param {Object}sidebar, get element from HTML
* @ param {Object}subNav, get element from HTML
* @ param {Object}fileList, create a fileList
* @ param {Object}files, create a file array
* @ param {function}closeAllSections, hidden pages function

 @ author: Zhiqing Liang & YangCheng Liu
 Date: April 24,2024
 Copyright(c) 2024 Newcastle University,UK
*/ 


// ---------------------------------- Side Panel Toggle -----------------------------------
const body = document.querySelector("body");
const toggle = body.querySelector(".toggle");
const sidebar = body.querySelector(".sidebar");
const subNav = body.querySelector(".subjectNav");

toggle.addEventListener("click", function() {
    sidebar.classList.toggle("close");
    subNav.classList.toggle("open")
});


// ---------------------------------- Subject Navigation -----------------------------------

document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll('.nav-link a'); // Select all navigation links
    const sections = document.querySelectorAll('section'); 

    // Function to close all sections
    function closeAllSections() {
        sections.forEach(section => {
            section.classList.add('close');
        });
    }
    
    // Open announcement by default
    const announcementSection = document.getElementById('announcement');
    announcementSection.classList.remove('close');
    

    // Event listeners for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetSection = document.querySelector(this.getAttribute('href')); 
            closeAllSections(); // Close all sections
            targetSection.classList.remove('close'); // Open the targeted section
        });
    });
});

//  ------ Get coursework's announcement ------
// Get coursework announcement

// Get fileList
const moduleCode = "CSC8019";
//var files = ["Lecture Slide 1.ppt", "Lecture Slide 2.ppt", "Lecture Slide 3.ppt","Lecture Slide 4.ppt"];

// Get the HTML element of the file list
var fileList = document.getElementById("fileList");
let files=[];
fetch(`http://localhost:8080/file/getMaterials?moduleCode=${moduleCode}`,{
  method: 'GET',
  headers: {'Content-Type': 'application/json',}
})
    .then(response => response.json())
    .then(data => {
    files = data;
    // Traverse the list of files
    for (var i = 0; i < files.length; i++) {
        //console.log(i);
          // Create a new list item
        var li = document.createElement("li");

        // Create a div for file information
        var div = document.createElement("div");

        // Create and set the img for the file icon
        var imgFile = document.createElement("img");
        imgFile.src = "IMG/PPTLogo.png";

         // Create and set a span of filenames
        var span = document.createElement("span");
        span.textContent = files[i];

        // Add the file icon and filename to the file info div
        div.appendChild(imgFile);
        div.appendChild(span);

        // Create and set the img for the download icon
        var imgDownload = document.createElement("img");
        imgDownload.className = "download";
        imgDownload.src = "IMG/download.png";

        // Add a click event listener for the download icon.
        imgDownload.addEventListener("click", function() {
                var filename = this.parentNode.querySelector("span").textContent;
//                   console.log(filename);
                // Send a GET request to the server for the file
                fetch(`http://localhost:8080/file/downloadMaterials?filename=${filename}&moduleCode=${moduleCode}`,{
                  method: 'GET',
                  headers: {'Content-Type': 'application/json',}
                })
                  .then(response => response.blob())  // Convert Response Data to Blob Objects
                  .then(blob => {
                    // Saving Blob Objects to the Front-End Cache
                    // We're using sessionStorage here as an example, but you can use other storage methods as well
                    let reader = new FileReader();
                    reader.onload = function() {
                      sessionStorage.setItem('file', this.result);
                    }
                    reader.readAsDataURL(blob);

                    // Create a URL to the Blob object
                    let url = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = url;
                    a.download = filename;
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                  })
                  .catch(error => console.error(error));
            });

        // Add file info divs and download icons to list items
        li.appendChild(div);
        li.appendChild(imgDownload);

        // Add the list item to the file list
        fileList.appendChild(li);
    }
    //console.log(files.length);
})
    .catch((error) => {
        console.error('Error:', error);
    });
//
var recapList = document.getElementById("recapList");
let recapFiles=[];
fetch(`http://localhost:8080/file/getRecaps?moduleCode=${moduleCode}`,{
  method: 'GET',
  headers: {'Content-Type': 'application/json',}
})
    .then(response => response.json())
    .then(data => {
    recapFiles = data;
    // Traverse the list of files
    for (var i = 0; i < recapFiles.length; i++) {
        //console.log(i);
        // Create a new list item
        var li = document.createElement("li");

        // Create a div for file information
        var div = document.createElement("div");

        // Create and set the img for the file icon
        var imgFile = document.createElement("img");
        imgFile.src = "IMG/recordIcon.png";

        // Create and set a span of filenames
        var span = document.createElement("span");
        span.textContent = recapFiles[i];

        // Add the file icon and filename to the file info div
        div.appendChild(imgFile);
        div.appendChild(span);

        // Create and set the img for the download icon
        var imgDownload = document.createElement("img");
        imgDownload.className = "download";
        imgDownload.src = "IMG/download.png";

        // Add a click event listener for the download icon.
        imgDownload.addEventListener("click", function() {
                var filename = this.parentNode.querySelector("span").textContent;
                // Send a GET request to the server for the file
                fetch(`http://localhost:8080/file/downloadRecaps?filename=${filename}&moduleCode=${moduleCode}`,{
                  method: 'GET',
                  headers: {'Content-Type': 'application/json',}
                })
                  .then(response => response.blob())  // Convert the response data into a Blob object
                  .then(blob => {
                    // Saving Blob Objects to the Front-End Cache
                    // We're using sessionStorage here as an example, but you can use other storage methods as well
                    let reader = new FileReader();
                    reader.onload = function() {
                      sessionStorage.setItem('file', this.result);
                    }
                    reader.readAsDataURL(blob);

                    // Create a URL to the Blob object
                    let url = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = url;
                    a.download = filename;
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                  })
                  .catch(error => console.error(error));
            });

        // Add file info divs and download icons to list items
        li.appendChild(div);
        li.appendChild(imgDownload);

        // Add the list item to the file list
        recapList.appendChild(li);
    }
})
    .catch((error) => {
        console.error('Error:', error);
    });





