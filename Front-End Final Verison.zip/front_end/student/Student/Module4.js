 /*
* @ param {Object}body, get element from HTML
* @ param {Object}toggle, get element from HTML
* @ param {Object}sidebar, get element from HTML
* @ param {Object}subNav, get element from HTML
* @ param {Object}fileList, create a fileList
* @ param {Object}files, create a file array
* @ param {function}closeAllSections, hidden pages function

 @ author: Zhiqing Liang & YangCheng Liu
 Date: April 25,2024
 Copyright(c) 2024 Newcastle University,UK
*/ 


// ---------------------------------- Side Panel Toggle -----------------------------------
const body = document.querySelector("body");
const toggle = body.querySelector(".toggle");
const sidebar = body.querySelector(".sidebar");
const subNav = body.querySelector(".subjectNav");

toggle.addEventListener("click", function() {
    sidebar.classList.toggle("close");
    subNav.classList.toggle("open")
});



// ---------------------------------- Subject Navigation -----------------------------------

document.addEventListener("DOMContentLoaded", function() {
    const navLinks = document.querySelectorAll('.nav-link a'); // Select all navigation links
    const sections = document.querySelectorAll('section');

    // Function to close all sections
    function closeAllSections() {
        sections.forEach(section => {
            section.classList.add('close');
        });
    }

    // Open announcement by default
    const announcementSection = document.getElementById('announcement');
    announcementSection.classList.remove('close');


    // Event listeners for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const targetSection = document.querySelector(this.getAttribute('href'));
            closeAllSections(); // Close all sections
            targetSection.classList.remove('close'); // Open the targeted section
        });
    });
});

//  ------ Get coursework's announcement ------

// //The following comments are the same as those for Module1

// Get fileList
const moduleCode = "CSC8014";
//var files = ["Lecture Slide 1.ppt", "Lecture Slide 2.ppt", "Lecture Slide 3.ppt","Lecture Slide 4.ppt"];

var fileList = document.getElementById("fileList");
let files=[];
fetch(`http://localhost:8080/file/getMaterials?moduleCode=${moduleCode}`,{
  method: 'GET',
  headers: {'Content-Type': 'application/json',}
})
    .then(response => response.json())
    .then(data => {
    files = data;

    for (var i = 0; i < files.length; i++) {
        //console.log(i);

        var li = document.createElement("li");
        var div = document.createElement("div");
        var imgFile = document.createElement("img");
        imgFile.src = "IMG/PPTLogo.png";

        var span = document.createElement("span");
        span.textContent = files[i];

        div.appendChild(imgFile);
        div.appendChild(span);

        var imgDownload = document.createElement("img");
        imgDownload.className = "download";
        imgDownload.src = "IMG/download.png";

        imgDownload.addEventListener("click", function() {
                var filename = this.parentNode.querySelector("span").textContent;
//                   console.log(filename);
                fetch(`http://localhost:8080/file/downloadMaterials?filename=${filename}&moduleCode=${moduleCode}`,{
                  method: 'GET',
                  headers: {'Content-Type': 'application/json',}
                })
                  .then(response => response.blob())
                  .then(blob => {
                    let reader = new FileReader();
                    reader.onload = function() {
                      sessionStorage.setItem('file', this.result);
                    }
                    reader.readAsDataURL(blob);

                    let url = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = url;
                    a.download = filename;
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                  })
                  .catch(error => console.error(error));
            });

        li.appendChild(div);
        li.appendChild(imgDownload);

        fileList.appendChild(li);
    }
    //console.log(files.length);
})
    .catch((error) => {
        console.error('Error:', error);
    });
//
var recapList = document.getElementById("recapList");
let recapFiles=[];
fetch(`http://localhost:8080/file/getRecaps?moduleCode=${moduleCode}`,{
  method: 'GET',
  headers: {'Content-Type': 'application/json',}
})
    .then(response => response.json())
    .then(data => {
    recapFiles = data;

    for (var i = 0; i < recapFiles.length; i++) {
        //console.log(i);

        var li = document.createElement("li");
        var div = document.createElement("div");
        var imgFile = document.createElement("img");
        imgFile.src = "IMG/recordIcon.png";

        var span = document.createElement("span");
        span.textContent = recapFiles[i];

        div.appendChild(imgFile);
        div.appendChild(span);


        var imgDownload = document.createElement("img");
        imgDownload.className = "download";
        imgDownload.src = "IMG/download.png";

        imgDownload.addEventListener("click", function() {
                var filename = this.parentNode.querySelector("span").textContent;
                fetch(`http://localhost:8080/file/downloadRecaps?filename=${filename}&moduleCode=${moduleCode}`,{
                  method: 'GET',
                  headers: {'Content-Type': 'application/json',}
                })
                  .then(response => response.blob())  
                  .then(blob => {
                    let reader = new FileReader();
                    reader.onload = function() {
                      sessionStorage.setItem('file', this.result);
                    }
                    reader.readAsDataURL(blob);

                    let url = URL.createObjectURL(blob);
                    var a = document.createElement("a");
                    a.href = url;
                    a.download = filename;
                    a.style.display = 'none';
                    document.body.appendChild(a);
                    a.click();
                    document.body.removeChild(a);
                  })
                  .catch(error => console.error(error));
            });

        li.appendChild(div);
        li.appendChild(imgDownload);

        recapList.appendChild(li);
    }
})
    .catch((error) => {
        console.error('Error:', error);
    });





