
/*@ author: Zhiqing Liang 
Date: April 21,2024
Copyright(c) 2024 Newcastle University,UK
*/ 

fetch('http://localhost:8080', { // Get feedback from backend
    method: 'GET',
    headers: {
        'Content-Type': 'application/json'
    }
})
.then(response => {
    if (!response.ok) {
        alert('Cannot get the data')
        throw new Error('fail to connect');
    }
    return response.json();
})
.then(data => {
    document.getElementById('content').textContent = data.feedback;
})
.catch(error => {
    console.error('wrong message:', error);
});

