 /*
 @ author: Zhiqing Liang & YangCheng Liu
 Date: April 20,2024
 Copyright(c) 2024 Newcastle University,UK
*/ 

//  Get element and add listener
const loginForm = document.getElementById('loginForm');
loginForm.addEventListener('submit',function(e){
    e.preventDefault();
    const username = document.getElementById("username").value;
    const email = document.getElementById("email").value;

    fetch('http://localhost:8080/student/active',{ // send email...
        method:'POST',
        headers:{
            "Content-Type":"application/json"
        },
        body:JSON.stringify({
            userID: username,
            email: email
        })
    })
    .then(Response => {
        if (!Response.ok) {
            return Response.text().then(text => {
                alert('Activation failed: ' + text);  // Use the message returned from the backend as a warning message
                throw new Error("Activation failed with status " + Response.status + ": " + text);
            });
        }
        return Response.text();
    })

    .then(text => {
        // data is now a text string containing the message returned from the backend
        console.log(text); // Print the messages returned by the backend for debugging purposes
        if (text === "successfully") {
            alert("You have activated your account");
            window.location.href = "DysonLogin.html"; // Jump on success
        }
    })
    .catch(error =>{
        console.error("Error is:" ,error);
    });
});